# AngularTombola
Italian Tombola written with AngularJS.

You can use it to remember drawn numbers or to draw numbers.

This is my first experiment with AngularJS. It's not perfect. It's just a starting point. Any comment will be appreciated.


